package com.robin.fb.signin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.robin.fb.input.GetInput;

public class DoSignIn extends GetInput {

	public static WebDriver driver ;
	
	
	@BeforeClass
	public static void start() throws Exception {
		System.out.println("Start....");
		GetInput.getFbInput();
		
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("permissions.default.desktop-notification", 1);
		DesiredCapabilities capability = DesiredCapabilities.firefox();
		capability.setCapability(FirefoxDriver.PROFILE, profile);
		
		System.setProperty("webdriver.gecko.driver", "driver/geckodriver.exe");
		 driver = new FirefoxDriver(capability);
		//WebDriver driver = new FirefoxDriver();
		driver.get(url);
		driver.manage().window().maximize();
	}
	
	@Test
	public static void doLogin() {
		driver.findElement(By.id("email")).sendKeys(user);
		driver.findElement(By.id("pass")).sendKeys(pass);
		driver.findElement(By.id("loginbutton")).click();
	}
	
	@Test
	public static void validateSignIn() {
		int home = driver.findElements(By.linkText("Home")).size();
		Assert.assertEquals(home, 1, "Home Page is NOT Loaded");
	}
	
	@AfterClass
	public static void stop() {
		driver.close();
		System.out.println("End...");
	}
	
}
