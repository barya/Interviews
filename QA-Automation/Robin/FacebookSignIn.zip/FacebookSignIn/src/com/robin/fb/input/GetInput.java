package com.robin.fb.input;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class GetInput {

	public static String url = null;
	public static String user = null;
	public static String pass = null;
	public static String input_path = "conf/input.properties";
	
	public static void getFbInput() throws Exception {
		
		Properties pr = new Properties();
		InputStream ins = new FileInputStream(input_path);
		pr.load(ins);
		url = pr.getProperty("com.robin.fb.url", "http://www.facebook.com");
		user = pr.getProperty("com.robin.fb.user");
		pass = pr.getProperty("com.robin.fb.password");
	}
	
}
